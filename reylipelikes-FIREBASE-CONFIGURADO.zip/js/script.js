function buscarPerfil() {
  const uid = document.getElementById("uid").value.trim();
  const key = document.getElementById("key").value.trim();
  const region = document.getElementById("region").value;
  if (!uid || !key) return alert("Preencha UID e Key");
  window.location.href = `perfil.html?uid=${uid}&key=${key}&region=${region}`;
}
