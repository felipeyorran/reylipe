const firebaseConfig = {
  apiKey: "AIzaSyBNm2QUKkrx8EY-XHaHRSmLtJfsPiJKApE",
  authDomain: "reylipelikes.firebaseapp.com",
  projectId: "reylipelikes",
  storageBucket: "reylipelikes.firebasestorage.app",
  messagingSenderId: "578732027713",
  appId: "1:578732027713:web:3d28529c1ae8a1413afbc0",
  measurementId: "G-KEGB6649P7",
  databaseURL: "https://reylipelikes-default-rtdb.firebaseio.com"
};