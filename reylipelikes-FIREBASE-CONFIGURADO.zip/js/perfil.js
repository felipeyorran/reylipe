const MAX_LIKES = 10000;
const COOLDOWN_HOURS = 10;
const params = new URLSearchParams(window.location.search);
const uid = params.get("uid");
const key = params.get("key");
const region = params.get("region");
const userId = localStorage.getItem("ff_user") || gerarId();
localStorage.setItem("ff_user", userId);

function gerarId() {
  return "user_" + Math.random().toString(36).substr(2, 9);
}

fetch(`https://www.public.freefireinfo.site/api/info/${region}/${uid}?key=${key}`)
  .then(res => res.json())
  .then(data => {
    document.getElementById("profile").innerHTML = `
      <img class="banner" src="${data["Account Banner Image"]}" />
      <div class="avatar-box">
        <img class="avatar" src="${data["Account Avatar Image"]}" />
        <div>
          <h2>${data["Account Name"]}</h2>
          <p>Nível: ${data["Account Level"]}</p>
          <p>Likes: ${data["Account Likes"]} ❤️</p>
          <button onclick="darLike('${uid}', '${data["Account Name"]}')">Curtir Perfil</button>
        </div>
      </div>
    `;
  })
  .catch(() => {
    document.getElementById("profile").innerHTML = `<p>Erro ao buscar perfil</p>`;
  });

function darLike(targetUid, nome) {
  const ref = firebase.database().ref(`likes/${targetUid}/${userId}`);
  const now = Date.now();
  ref.get().then(snapshot => {
    const data = snapshot.val() || { count: 0, lastLike: 0 };
    const diff = (now - data.lastLike) / (1000 * 60 * 60);
    if (data.count >= MAX_LIKES && diff < COOLDOWN_HOURS) {
      alert(`Você já curtiu ${MAX_LIKES} vezes. Espere ${Math.ceil(COOLDOWN_HOURS - diff)} horas.`);
      return;
    }
    ref.set({ count: data.count + 1, lastLike: now }).then(() => {
      alert(`Você curtiu ${nome}! Total: ${data.count + 1}`);
    });
  });
}
